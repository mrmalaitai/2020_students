#Create a window
#Create something that will read the folder
#Choose a year/folder
#Find all the files with the word "final", put file into a list oe aomething similar
#See position of each "club"
#Give the club points 
#Add all the points form all the final files
#Present them to the user